from resources.lib.base.l5.service import main
main()